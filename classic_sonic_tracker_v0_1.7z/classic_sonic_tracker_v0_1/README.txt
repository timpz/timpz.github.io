Classic Sonic Tracker v0.1
- A live statistics tracker for classic Sonic games

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Made by Tim Lundberg
https://timpz.tv for all my contact information
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-


Version 0.1
-=-=-=-=-=-
Use these checksums to verify your build is unmodified:
MD5: 7E1FFEAD1C53C1B742C3678314103D60
SHA1: 5473C7714A521EAC5704BEB7C8464FEC97637778

A powershell script is provided which calculates these values using the Get-FileHash utility, simply right-click the .ps1 file and run with powershell.

!! WARNING !!
IF YOUR ANTIVIRUS DETECTS A POTENTIAL THREAT, ALWAYS VERIFY THE CHECKSUM!


Attribution
-=-=-=-=-=-
This program would not be possible without the following software and resources:

* RemedyBG Windows Debugger: https://remedybg.itch.io/remedybg
* Cheat Engine: https://www.cheatengine.org
* Exodus Emulator: https://www.exodusemulator.com
* Sonic 2 RAM locations: https://info.sonicretro.org/SCHG:Sonic_the_Hedgehog_2_(16-bit)/RAM_Editing
* Sonic 2 Disassembly: https://github.com/sonicretro/s2disasm


Compatibility
-=-=-=-=-=-=-
* genesis_plus_gx_libretro.dll running in Retroarch
* Sonic Compilation (a.k.a Sonic Classics) 1997 US Release
 -Code: GM MK-1190 -01yZJ


Getting Started
-=-=-=-=-=-=-=-
Once the tracker is launched, it will look for Retroarch running on your system. If you have multiple instances running, it will pick the first handle that's given by the Windows CreateToolhelp32Snapshot API.

When the process has been found, it will iterate through the loaded modules every 2.4 seconds until "genesis_plus_gx_libretro.dll" has been found. There are typically two dll's running at the same time and the first in the module list will be chosen.

At this point the program will look for the ROM being loaded in Retroarch's RAM. There seems to be a point where this ROM is unloaded after the DLL has loaded it, so if the game is running in retroarch and can't be found by the program try to close Retroarch and keep it closed for a few seconds then run it again. If it still doesn't work after multiple reloads, try clearing Retroarch's cache manually.

The specific string in the ROM that's looked for is the following (without quotes):
"SEGA MEGA DRIVE (C)SEGA 1997.JanSONIC COMPILATION                               SONIC COMPILATION                               GM MK-1190 -01yZJ"

If you are having a problem getting the process to recognise the game, check that this exact string is set in location 0x100 in the ROM binary.

If a recognised ROM is found, the program will check that the game's checksum routine has ran successfully by looking at the last 16 bytes in RAM. When this check is passed the program should tell you which game has been detected and start its tracking routine.


Refresh Command
-=-=-=-=-=-=-=-
The windows console host is notoriously slow to update and this could have an impact on performance when running the program at a high refresh rate on a low-end computer. For this reason the default behaviour is to only update the window information at 5 Hz during normal gameplay. By enabling debug this refresh rate will be set to 60 Hz to enable real-time viewing of the tracked information.

If the user wishes to override this refresh rate they can run the program with the "-refresh" command, followed by a number between 1 and 1000 in number of refreshes per second. In this way the user can force the refresh rate to be set at any rate.

A batch file has been provided which executes the program with the "-refresh" command set to 120 Hz. The user can edit this batch file directly or use it as a reference to create their own shortcuts.


Default information
-=-=-=-=-=-=-=-=-=-
If the game is running normally, the program should tell you it's "Ready to track" while showing the inputs from the running demo. If a new game is started, it will switch to "Tracking active" followed by the current level short name and current game state.

After it will show some statistics that are not hidden from the player, for example number of deaths or rings collected, the total of which are in parenthesis. For each level cleared, these statistics will update on a per-level basis. Some statistics like your number of perfect spindashes will be shown after the level has finished.

Once the game is cleared, more statistics will be shown including your spindash statistics. This includes the average spindash speed; i.e. how close to a perfect spindash the player's spindash execution was, and the average actual spindash speed; i.e. the average speed of the spindashes that were actually executed. Since the spindash is capped and floored to 9 possible speeds, the actual value will always be equal or lower than the regular average.

There is also the calculated IGT and adjusted IGT. Regular IGT is calculated like the game displays, by flooring the end-times of each level. The adjusted IGT keeps the decimals of each level end-time and gives a more accurate result overall.

There's also lag-frame values for each level. These are not included into the IGT as the game physics don't run while they pass, but are relevant for real-time runs.

Lastly, the program keeps track of which centisecond you died or entered a special stage, so the IGT tracked should be accurate with these in mind.


Debug information
-=-=-=-=-=-=-=-=-
While debug is enabled in the game, additional information will be shown, the first being the hit timer. This timer is set to 120 frames after the player character is hit and decreases every frame after landing on the ground or some solid object.

Next is the X and Y positions of the player characters including the subpixel values. It also shows the velocity in subpixels per frame and the characters inertia. Inertia here is a term for the absolute velocity irregardless of direction, while the X and Y velocities are only in relation to the level coordinates

At the very bottom are values related to the spindash taken directly from the game's RAM. The spindash count is effectively the charge of the spindash and goes between the values 0 and 2048 inclusive, 2048 being the highest possible count. This value decreases every frame more rapidly at higher counts, making fast spindashes harder to execute. Beside the count is the spindash speed, which is the inertia in subpixels per frame that the character got when they last released a spindash. Following that are human-readable percentages showing how close the player was to the maximum count and the maximum actual speed given on release.


Roadmap
-=-=-=-
As of version 0.1 this program only supports Retroarch running Sonic the Hedgehog 2 in the US version of Sonic Compilation for the Sega Mega Drive released in 1997 using the genesis_plus_gx_libretro.dll. Some time in the future, support for the original 1992 US release of Sonic the Hedgehog 2 is also planned. Other games or emulators are not planned at this time.

Not included in this release is a client that is capable of sending HTTP POST messages to a server. At this time this feature is only available upon special request.

Exporting the final statistics as a JSON file when the game is completed is planned for the next release.


Bug reporting
-=-=-=-=-=-=-
Because the process of reading RAM is not synchronised to the DLL thread, there will be times when the values are updated while copying it to the programs buffer. For this reason there can be rare occurances of values that are slightly incorrect, e.g. the IGT of a level being off by a frame or the level name for SC/WF being incorrect. This is not a bug and should not be reported.

Some values like lag frames or pauses are included in the total number but not counted for any specific level after the score counter at the end has been loaded. This is a feature, not a bug.

If savestates are used, it could mess with many of the statistics tracked. Therefore it's recommended to hard reset the game before tracking any runs. Do not report any issues related to the use of savestates.

If the value is severly incorrect (i.e. something that could not be caused by a single frame being read incorrectly) or the issue is reproducible you can report the issue. Please provide as much context and information as possible, including steps to reproduce and a video recording if possible.


Virus detection
-=-=-=-=-=-=-=-
!! WARNING !!
IF THIS PROGRAM WAS NOT PROVIDED DIRECTLY FROM THE SOURCE, THIS README COULD BE TAMPERED WITH. ALWAYS VERIFY THE CHECKSUM IF YOUR ANTIVIRUS DETECS ANY POTENTIAL THREATS!

Since this program is designed to read the RAM of another process, it's possible that some antivirus software might flag it as suspicious or infected. This should be rare for most users as it's running without elevated privileges and reading shared memory from another process that doesn't require elevated privileges. Nevertheless, these warnings can be safely ignored, and if encountered can be avoided by adding the executable to a list of exceptions.


Legal
-=-=-
Copyright (C) 2024 Tim Lundberg

This software is provided free of charge. The user is free to use and distribute the software for any purpose except to sell and/or sublicense copies of the software, with or without modifications.

This software is provided "as is" without warranty of any kind. Use at your own risk.