$filePath = "Classic Sonic Tracker v0_1.exe"

Get-FileHash -Path $filePath -Algorithm MD5 | Format-List
Get-FileHash -Path $filePath -Algorithm SHA1 | Format-List

Write-Host "Press any key to exit..."
$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")